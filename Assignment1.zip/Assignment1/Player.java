/** Player class allows for storage and recall of player related
 * details, such as Name, Age, and Height.
 * @author Joseph M. Baskin
 * @version 1.0
 */
public class Player {
    /** Stores a String as playerName */
    private String playerName;
    /** Stores an Integer as playerAge*/
    private int playerAge;
    /** Stores a Height class as playerHeight */
    private Height playerHeight;

    /** No-arg constructor that creates an empty Player */
    public Player() {}

    /** Constructor that converts a single String (s) to needed player details
     * @param s Player's Name, Age, and Height as a String
     */
    public Player(String s) {
        String[] player = s.split(" ");
        this.playerName = player[0];
        this.playerAge = Integer.parseInt(player[1]);
        this.playerHeight = new Height(Integer.parseInt(player[2]), Integer.parseInt(player[3]));
    }
    /** @return Returns String for Player.playerName */
    public String getPlayerName() { return this.playerName; }
    /** @return Returns Integer for Player.plagerAge */
    public int getPlayerAge() { return this.playerAge; }
    /** @return Returns String for Height.toString */
    public String getPlayerHeight() { return this.playerHeight.toString(); }
    /** @return Returns Integer for Height.toInches */
    public int getPlayerHeightInches() { return this.playerHeight.toInches(); }

    /** @return Returns full player Name Age and Height (ie, Joe 37 5' 10") */
    public String toString() {
        return "Name: " + this.playerName + " Age: " + this.playerAge + " Height: " + this.playerHeight.toString();
    }
}
