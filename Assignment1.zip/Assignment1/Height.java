/** Stores height-related data for the Player class and can return
 * height as Integer or as a String.
 * @author Joseph M. Baskin
 * @version 1.0
 */
public class Height extends Player {
    /** Private variable for Player's height in feet (ie 5 in 5' 10") */
    private int feet;
    /** Private variables for Player's height in inches (ie 10 in 5' 10") */
    private int inch;

    /** Constructor that builds a Height class object to store Player's 
     * height.
     * @param f Player's height in feet (ie 5 in 5' 10")
     * @param i Player's height in inches (ie 10 in 5' 10")
     */
    public Height(int f, int i) {
        super();
        // If inches (i) is 12 or more, calculate and add to Feet (f) and store remainder as i.
        if (i > 11) {
            this.feet = f + (i / 12);
            this.inch = i % 12;
        } else {
            this.feet = f;
            this.inch = i;
        }
    }

    /** @return Returns player's height in total inches as an Integer (in") */
    public int toInches() {
        return (this.feet * 12) + (this.inch);
    }

    /** @return Returns player's height formatted as (ft' in") */
    @Override
    public String toString() {
        return this.feet + "\' " + this.inch + "\"";
    }
}
