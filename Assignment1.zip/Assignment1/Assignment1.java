/**
 * @author Joseph M. Baskin
 * @version 1.0
 */
import java.util.Scanner;
import java.util.ArrayList;

/** Return's the tallest player whose age is less than the average of all
 * player's ages entered in to the program */
public class Assignment1 {
    /** 
     * @param args No required arguments.
     */ 
    public static void main(String[] args) {
        ArrayList<Player> players = new ArrayList<>();
        double sumOfAges = 0;
        double averageAge = 0;
        int tallestPlayerInches = 0;
        int tallestPlayerIndex = 0;
        int count = 0;

        Scanner inputString = new Scanner(System.in);

        // Continue to ask for player information until the length of the string entered is 0.
        // Add each string to ArrayList players as a new Player.
        while (true) {
            System.out.print("Enter the player's Name, Age, and Height (in feet and inches): ");
            String line = inputString.nextLine();
            if (line.length() == 0) {
                break;
            } else {
                players.add(new Player(line));
            }
        }

        inputString.close();

        for (Player player : players) {
            sumOfAges += player.getPlayerAge();
        }

        averageAge = sumOfAges / players.size();

        System.out.println();
        System.out.println("The average age of all players is " + averageAge);

        for (Player player : players) {
            if (player.getPlayerAge() < averageAge) {
                if (player.getPlayerHeightInches() > tallestPlayerInches) {
                    tallestPlayerIndex = count;
                    tallestPlayerInches = player.getPlayerHeightInches();
                }
            }
            count++;
        }

        System.out.println("The tallest player whose age is less than the average is:\n    " +
            players.get(tallestPlayerIndex).toString());
    }
}
